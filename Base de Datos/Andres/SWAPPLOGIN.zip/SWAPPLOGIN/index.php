<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link href="https://fonts.googleapis.com/css?family=Kalam&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="Assets/CSS/style.css?v=<?php echo time(); ?>"/>
</head>
<body>
    <?php require 'Partials/Header.php'?>
    <h1>Please Login or Sign up</h1>
    <a href="Login.php">Login</a> or 
    <a href="Signup.php">Sign up</a>
    <h2>Prueba exitosa</h2>

</body>
</html>